import os
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from dotenv import load_dotenv

# Import our command handlers
from commands import (
    handle_mudrac,
    handle_coffee,
    handle_motivate,
    handle_fun,
    handle_find
)

# Load environment variables from .env file
load_dotenv()

# Initialize the Slack app
app = App(
    token=os.environ.get("SLACK_BOT_TOKEN"),
    signing_secret=os.environ.get("SLACK_SIGNING_SECRET")
)

# Register all 5 slash commands
app.command("/mudrac")(handle_mudrac)
app.command("/coffee")(handle_coffee)
app.command("/motivate")(handle_motivate)
app.command("/fun")(handle_fun)
app.command("/find")(handle_find)

# If you want to catch ALL errors globally
# Uncomment this:
# @app.error
# def global_error_handler(error, body, logger):
#     logger.exception(error)

if __name__ == "__main__":
    # Get the App-Level token for Socket Mode
    app_token = os.environ.get("SLACK_APP_TOKEN")
    if not app_token:
        print("SLACK_APP_TOKEN not found in .env file!")
        print("   Please add it. It starts with 'xapp-'")
    else:
        print("Mudrac is running! Go test your commands in Slack.")
        SocketModeHandler(app, app_token).start()
